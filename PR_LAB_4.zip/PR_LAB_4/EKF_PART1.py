from GFLocalization import *
from EKF import *
from DR_3DOFDifferentialDrive import *
from DifferentialDriveSimulatedRobot import *
import os

class EKF_3DOFDifferentialDriveInputDisplacement(GFLocalization, DR_3DOFDifferentialDrive, EKF):
    """
    This class implements an EKF localization filter for a 3 DOF Diffenteial Drive using an input displacement motion model incorporating
    yaw measurements from the compass sensor.
    It inherits from :class:`GFLocalization.GFLocalization` to implement a localization filter, from the :class:`DR_3DOFDifferentialDrive.DR_3DOFDifferentialDrive` class and, finally, it inherits from
    :class:`EKF.EKF` to use the EKF Gaussian filter implementation for the localization.
    """
    def __init__(self, kSteps, robot, *args):
        """
        Constructor. Creates the list of  :class:`IndexStruct.IndexStruct` instances which is required for the automated plotting of the results.
        Then it defines the inital stawe vecto mean and covariance matrix and initializes the ancestor classes.

        :param kSteps: number of iterations of the localization loop
        :param robot: simulated robot object
        :param args: arguments to be passed to the base class constructor
        """

        self.dt = 0.1  # dt is the sampling time at which we iterate the KF
        x0 = np.zeros((3, 1))  # initial state x0=[x y z psi u v w r]^T\\
        P0 = np.zeros((3, 3))  # initial covariance

        # this is required for plotting
        index = [IndexStruct("x", 0, None), IndexStruct("y", 1, None), IndexStruct("z", 2, 0), IndexStruct("yaw", 3, 1)]

        self.t_1 = 0
        self.t = 0
        self.Dt = self.t - self.t_1

        # TODO
        self.input_list = []
        self.wk = np.zeros((3,1))
        super().__init__(index, kSteps, robot, x0, P0, filter, *args)

    def f(self, xk_1, uk):
        """
        Motion model of the EKF.

        :param xk_1: previous mean state vector
        :param uk: input vector
        :return xk_bar, Pk_bar: predicted mean state vector and its covariance matrix
        """
        # TODO: To be completed by the studentù
        xk_bar = Pose3D.oplus(xk_1, uk)        
        return xk_bar

    def Jfx(self, xk_1):
        """
        Jacobian of the motion model with respect to the state vector.

        :param xk_1: Linearization point. By default the linearization point is the previous state vector taken from a class attribute.
        :return: Jacobian matrix
        """
        # TODO: To be completed by the student

        J = Pose3D.J_1oplus(xk_1, self.uk)
        return J

    def Jfw(self, xk_1):
        """
        Jacobian of the motion model with respect to the noise vector.

        :param xk_1: Linearization point. By default the linearization point is the previous state vector taken from a class attribute.
        :return: Jacobian matrix
        """
        # TODO: To be completed by the student

        #J = Pose3D.J_2oplus(xk_1)
        theta = xk_1[2].item()
        J = np.array([[-np.sin(theta),  0],
                      [ np.cos(theta),  0],
                      [             0,  1]])
        return J

    def h(self, xk):  #:hm(self, xk):
        """
        The observation model of the EKF is given by:

        .. math::
            z_k=h(x_k,v_k)
            :label: eq-EKF-observation-model

        This method computes the mean of this direct observation model. Therefore it does not depend on v_k since it is
        a zero mean Gaussian noise.

        :param xk: mean of the predicted state vector. By default it is taken from the class attribute.
        :return: expected observation vector
        """
        # TODO: To be completed by the student
        h = xk[2] 
        return h  # return the expected observations

    def GetInput(self):
        """
        The sensor input in this robot are the encoders and the compass reader.
        The encoder return an array of pulses and their covariance.
        the reading compass return the yaw and its covariance.

        **Outputs** :\n
        **uk**: 2x1 np.array [d, dTheta] displacement of the robot and displacement of the angle\n
        **Qk**: 2x2 np diagonal matrix, covariance of the input \n
        """
        # TODO: To be completed by the student
        # receive input from simulated robot
        encIn, encCov = self.robot.ReadEncoders() # reurtn impulses for each wheel andcovariance of input

        # converting encoders read into a displacement
        r = self.wheelRadius # radius of the wheels
        L = self.wheelBase
        pulse_round = (self.robot.pulse_x_wheelTurns) # pulses wheel evolution

        omega_l = (encIn[0] / pulse_round) * 2 * np.pi
        omega_r = (encIn[1] / pulse_round) * 2 * np.pi

        # Angular displacement of the wheels
        disp_l = omega_l * r
        disp_r = omega_r * r
    
        # Compute robot displacement and angular displacement
        d = (disp_l + disp_r) / 2  # Linear displacement in the robot's frame
        dTheta = (r / L) * (omega_r - omega_l)  # Angular displacement (yaw change)
        # dCov = (encCov[0] / pulse_round)  * 2 * np.pi * r # converting impulses covariances into displacement covariances

        # Convert to scalars if needed
        d = d.item()
        dTheta = dTheta.item()

        # Construct input vector
        uk = np.array([d, 0, dTheta]).reshape(3, 1)

        # Covariance of the input (approximated) 
        # TODO Qk = np.diag((dCov[0],dCov[0]))

        # Covariance in encoder pulses
        sigma_l = np.sqrt(encCov[0,0]) 
        sigma_r = np.sqrt(encCov[1,1])

        # Compute uncertainties
        wheel_uncertainty_l = sigma_l * (2 * np.pi) / pulse_round * r
        wheel_uncertainty_r = sigma_r * (2 * np.pi) / pulse_round * r

        linear_uncertainty = (wheel_uncertainty_l + wheel_uncertainty_r) / 2
        angular_uncertainty = (r / L) * abs(wheel_uncertainty_r - wheel_uncertainty_l)
        # Process noise covariance
        Qk = np.diag([linear_uncertainty**2, angular_uncertainty**2])

        return uk, Qk

    def GetMeasurements(self):  # override the observation model
        """
        The measurement in this robot is made by distance sensor.

        **Outputs** :\n
        **zk**: compass reading\n
        **Rk**: 2x2 np diagonal matrix, covariance of the readings \n
        **Hk**: 3x3 np matrix, Jacobian of the state measurement wtr measurement
        **Vk**: 3x3 np matrix, Jacobian of the state measurement wtr noise 
        """
        # TODO: To be completed by the student
        zk, Rk = self.robot.ReadCompass()

        # define measurement vector
        Hk = np.zeros((1, 3))
        Hk[0, 2] = 1

        # Jacobian of the measurement
        Vk = np.array([1])

        return zk, Rk, Hk, Vk


if __name__ == '__main__':

    # TODO: understand why this doesn't work

    # M = [CartesianFeature(np.array([[-40, 5]]).T),
    #        CartesianFeature(np.array([[-5, 40]]).T),
    #        CartesianFeature(np.array([[-5, 25]]).T),
    #        CartesianFeature(np.array([[-3, 50]]).T),
    #        CartesianFeature(np.array([[-20, 3]]).T),
    #        CartesianFeature(np.array([[40,-40]]).T)]  # feature map. Position of 2 point features in the world frame.
    
    todo_list = []

    todo_list.append("implement a modular Jacobian for the J2oplus")


    print(3*"\n",  15*"*", 3*"\t", " TODO LIST\n", todo_list)

    M =   [(np.array([[-40, 5]]).T),
           (np.array([[-5, 40]]).T),
           (np.array([[-5, 25]]).T),
           (np.array([[-3, 50]]).T),
           (np.array([[-20, 3]]).T),
           (np.array([[40,-40]]).T)]  # feature map. Position of 2 point features in the world frame.

    xs0 = np.zeros((6,1))  # initial simulated robot pose x_sk = [x y theta u v r].T
    usk = np.array([[0.5, 0.03]]).T # input model simulated robot
    robot = DifferentialDriveSimulatedRobot(xs0, M)  # instantiate the simulated robot object

    kSteps = 5000

    index = [IndexStruct("x", 0, None), IndexStruct("y", 1, None), IndexStruct("yaw", 2, 1)]

    x0 = np.zeros((3, 1)) # initial predicted robot pose x_k = [x y theta].T
    P0 = np.diag((0.1, 0.1, 0.1)) # initial covariance predicted robot


    dd_robot = EKF_3DOFDifferentialDriveInputDisplacement(kSteps,robot)  # initialize robot and KF
    dd_robot.LocalizationLoop(x0, P0, usk) # call loop
    
    exit(0)