from GaussianFilter import *
import numpy as np
class EKF(GaussianFilter):
    """
    Extended Kalman Filter class. Implements the :class:`GaussianFilter` interface for the particular case of the Extended Kalman Filter.
    """
    def __init__(self, x0, P0, *args):
        """
        Constructor of the EKF class.

        :param x0: initial mean state vector
        :param P0: initial covariance matrix
        :param args: arguments to be passed to the parent class
        """
        super().__init__(x0, P0, *args)  # call parent constructor

    def f(self, xk_1, uk): # motion model
        """
        Motion model of the EKF **to be overwritten by the child class**.

        :param xk_1: previous mean state vector
        :param uk: input vector
        :return xk_bar, Pk_bar: predicted mean state vector and its covariance matrix
        """
        pass

    def Jfx(self, xk_1):
        """
        Jacobian of the motion model with respect to the state vector. **Method to be overwritten by the child class**.

        :param xk_1: Linearization point. By default the linearization point is the previous state vector taken from a class attribute.
        :return: Jacobian matrix
        """
        pass

    def Jfw(self, xk_1):
        """
        Jacobian of the motion model with respect to the noise vector. **Method to be overwritten by the child class**.

        :param xk_1: Linearization point. By default the linearization point is the previous state vector taken from a class attribute.
        :return: Jacobian matrix
        """
        pass

    def h(self, xk):  # observation model
        """
        The observation model of the EKF is given by:

            zk=h(xk,vk)
            q-EKF-observation-model

        This method computes the mean of this direct observation model. Therefore it does not depend on vk since it is
        a zero mean Gaussian noise.

        :param xk: mean of the predicted state vector. By default it is taken from the class attribute.
        :return: expected observation vector
        """
        pass

    def Prediction(self, uk, Qk, xk_1=None, Pk_1=None):
        """
        Prediction step of the EKF. It calls the motion model and its Jacobians to predict the state vector and its covariance matrix.

        Parameters:
            uk: input vector
            Qk: covariance matrix of the noise vector
            xk_1: previous mean state vector. By default it is taken from the class attribute. Otherwise it updates the class attribute.
            Pk_1: covariance matrix of the previous state vector. By default it is taken from the class attribute. Otherwise it updates the class attribute.
        Returns:
            xk_bar: predicted mean state vector
            Pk_bar: covariance matrix predicted state vector. 
            Also updated in the class attributes.
        """
        # logging for plotting
        self.xk_1 = xk_1 if xk_1 is not None else self.xk_1
        self.Pk_1 = Pk_1 if Pk_1 is not None else self.Pk_1

        self.uk = uk
        self.Qk = Qk  # store the input and noise covariance for logging

        xk_bar = self.f(xk_1, uk) # Prediction state estimate

        Ak = self.Jfx(xk_1) # Jacobian of the state

        Wk = self.Jfw(xk_1) # Jacobian of the noise process

        Pk_bar =  Ak @ Pk_1 @ Ak.T + Wk @ Qk @ Wk.T # Prediction covariance
        
        # Update belief
        self.xk_bar = xk_bar
        self.Pk_bar = Pk_bar

        return self.xk_bar, self.Pk_bar

    def Update(self, zk, Rk, xk_bar, Pk_bar, Hk, Vk):
        """
        Update step of the EKF. It calls the observation model and its Jacobians to update the state vector and its covariance matrix.

        Parameters:
            zk: observation vector
            Rk: covariance matrix of the noise vector
            xk_bar: predicted mean state vector.
            Pk_bar: covariance matrix of the predicted state vector.
            Hk: Jacobian of the observation model with respect to the state vector.
            Vk: Jacobian of the observation model with respect to the noise vector.
        Returns:
            xk: updated mean state vector
            Pk: covariance state vector
            self.: updated in the class attributes.
        """
        # logging for plotting
        self.xk_bar = xk_bar
        self.Pk_bar = Pk_bar
        self.zk = zk
        self.nz = zk.shape[0];  # store dimensionality of the observation
        self.Rk = Rk  # store the observation and noise covariance for logging

        # KF equations begin here
        
        # Hk: (9,3)
        # Pk_bar: (3,3)
        # Vk: (5,5) ?
        # Rk: (9,9)
        Sk = (Hk @ Pk_bar @ Hk.T + Vk @ np.array(Rk) @ Vk.T) # Innovation covariance
        Kk = Pk_bar @ Hk.T @ np.linalg.pinv(Sk) # Kalman gain

        #xk = xk_bar + Kk @ (zk - Hk @ xk_bar) # Update state estimate
        xk = xk_bar + Kk @ (zk - self.h(xk_bar, self.Hp))
        
        expected_z = self.h(xk_bar)
        if len(zk) < 2:
            if len(zk) < 1:
                zk = 0
                expected_z = 0
            else:
                zk = zk[0]
                expected_z = expected_z[0]
            yk = zk - expected_z
            xk = xk_bar + Kk * yk
        else:
            yk = zk - expected_z
            xk = xk_bar + Kk @ yk
        # NOTE: why update in this way?
        #xk = xk_bar
        #xk[2] = xk_bar[2] + Kk[2] * yk # Update state estimate
         # Update state estimate

        I = np.eye(Pk_bar.shape[0])
        Pk = (I - Kk @ Hk) @ Pk_bar # Update covariance

        self.xk = xk
        self.Pk = Pk

        return self.xk, self.Pk
