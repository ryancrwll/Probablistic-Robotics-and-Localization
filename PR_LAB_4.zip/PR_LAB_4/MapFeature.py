import numpy as np
from Feature import *

class MapFeature:
    """
    This class provides the functionality required to use Map Features for Robot     Localization. It has methods for reading
    the feature pose using the robot the sensors (:meth:`GetFeatures`), as well as for computing its:

        * observation model  (:meth:`hf`),
        * inverse observation model (:meth:`g`)
        * and all the required Jacobians (:meth:`Jhfx`, :meth:`Jhfv`, :meth:`Jgx` and :meth:`Jgv`).

    When mapped, a feature may involve 2 different representations:

    * **The observation representation:** which is the representation used by the sensors to observe the feature.
    * **The storage representation:** which is the representation used to store the feature in the map within the state vector.

    For instance, a feature may be observed in polar coordinates but stored in Cartesian coordinates. In this case, the
    observation representation is the Polar coordinates and the storage representation is the Cartesian coordinates. The
    class provides methods to convert from one representation to the other (:meth:`s2o` and :meth:`o2s`) and their corresponding
    Jacobians (:meth:`J_s2o` and :meth:`J_o2s`). By default, the observation representation is the same as the storage representation,
    but this behaviour may be overriden in child classes.
    """

    def __init__(self,*args):

        super().__init__(*args)

    def GetFeatures(self):
        """
        Reads the Feature observations from the sensors. For all features within the field of view of the sensor, the
        method returns the list of robot-related poses, the covariance of their corresponding observation noise, the
        corresponding observation matrix and the noise Jacobian matrix.
        **This is a pure virtual method that must be overriden in child classes**.

        :returns: vector of features observations in the B-Frame and the covariance of their corresponding noise.

            * :math:`z_k=[^Bx_{F_i}^T \\cdots ^Bx_{F_j}^T \\cdots ^Bx_{F_k}^T]^T`
            * :math:`R_k=block\\_diag([R_{F_i} \\cdots R_{F_j} \\cdots R_{F_k}])`
            * :math:`H_k=block\\_diag([H_{F_i} \\cdots H_{F_j} \\cdots H_{F_k}])`
            * :MATH:`V_K=I_{z_{nf} \\times z_{nf}}`
        """
        pass

    def s2o(self, v):
        """
        Conversion function from the storage representation to the observation representation.
        By default, it returns the same vector as the one provided as input, assuming that the observation representation is the same as the storage representation.
        In case it is not, this method must be overriden in the child class.

        :param v: vector in the storage representation
        :return: vector in the observation representation
        """
        Observation_representation = v

        return Observation_representation

    def o2s(self, v):
        """
        Conversion function from the observation representation to the storage representation. By default, it returns the
        same vector as the one provided as input, assuming that the observation representation is the same as the storage representation.
        In case it is not, this method must be overriden in child classes.

        :param v: vector in the observation representation
        :return: vector in the storage representation
        """
        # TODO: To be implemented by the student
        Storage_representation = v
        return Storage_representation

    def J_s2o(self, v):
        """
        Jacobian of the conversion function from the storage representation to the observation representation.
        By default, it returns the identity matrix, assuming that the observation representation is the same as the storage representation.
        In case it is not, this method must be overriden in the derived class.

        :param v: vector in the storage representation
        :return: Jacobian of the conversion function from the storage representation to the observation representation
        """
        # TODO: To be implemented by the student
        J = np.eye(v.shape[0])

        return J

    def J_o2s(self, v):
        """
        Jacobian of the conversion function from the observation representation to the storage representation.
        By default, it returns the identity matrix, assuming that the observation representation is the same as the storage representation.
        In case it is not, this method must be overriden in the derived class.

        :param v: vector in the observation representation
        :return: Jacobian of the conversion function from the observation representation to the storage representation
        """
        # TODO: To be implemented by the student
        J = np.eye(v.shape[0])

        return J

    def hf(self, xk, Pk_bar):  # Observation function for al zf observations
        """
        This is the direct observation model, implementing the feature observation equation for the data
        association hypothesis H, the features observation vector zf, the state vector xk, and the observation noise vk:

        [zf_1, ..., zfn]^T = [hf_1(xk, vk), ..., hf_n(xk, vk)]^T = [s2o(BxN boxplus NxF1) + vf1, ... , s2o(BxN boxplus NxFn) + vfn]^T

        which may be expanded as follows:

        being hfHi() the observation function Jhfv for the data association hypothesisH and s2o the conversion function from the 
        storage representation to the observation one.

        The method computes the expected observations hf for the observed features contained within the zf features observation vector.
        To do it, it iterates over each feature observation zf[i] calling the method Hfj() for its corresponding associated feature H[i]=Fj`
        to compute the expected observation Fj, collecting all them in the returned vector.

        Parameters:
            xk: state vector
            Pk_bar: predicted covariance state vector.
        Returns:
            _hf: vector of expected features observations corresponding to the vector of observed features zf.
        """
        # Get list of ranges
        zf, Rf = self.GetFeatures()

        # Init empty vector
        _hf = []

        # Associate datas
        H = self.DataAssociation(xk, Pk_bar, zf, Rf)
        self.Fj = []
        for Fj in range(len(zf)):
            if H[Fj] != -1:
                _hf.append(self.hfj(xk,Fj))
                self.Fj.append(Fj)

        _hf = np.array(_hf)
        return _hf

    def Jhfx(self, xk, Pk_bar):  # Jacobian wrt x of the feature observation function for all zf observations
        """
        Computes the Jacobian of the feature observation function :meth:`hf` (eq. :eq:`eq-hf`), with respect to the state vector :math:`\\bar{x}_k`:

        .. math::
            J_{hfx}=\\frac{\\partial h_f(x_k,v_k)}{\\partial x_k}=\\begin{bmatrix} \\frac{\\partial h_{F_{a}}(x_k,v_k)}{\\partial x_k} \\\\ \\vdots \\\\ \\frac{\\partial h_{F_{b}}(x_k,v_k)}{\\partial x_k} \\\\ \\vdots \\\\ \\frac{\\partial h_{F_{c}}(x_k,v_k)}{\\partial x_k} \\end{bmatrix}
            =\\begin{bmatrix} J_{h_{F_a}} \\\\ \\vdots \\\\ J_{h_{F_b}} \\\\ \\vdots \\\\ J_{h_{F_c}} \\end{bmatrix}
            :label: eq-Jhfx

        where :math:`J_{h_{F_j}}` is the Jacobian of the observation function :meth:`hfj` (eq. :eq:`eq-Jhfjx`) for the feature :math:`F_j`and observation :math:`z_{f_i}`.
        To do it, given a vector of observations :math:`z_f=[z_{f_1}~\\cdots~z_{f_i}~\\cdots~z_{f_{n_{zf}}}]` this method iterates over each feature observation :math:`z_{f_i}` calling the method :meth:`Jhfj` to compute
        the Jacobian of the observation function for each feature observation (:math:`J_{hfj}`), collecting all them in the returned Jacobian matrix :math:`J_{hfx}`.

        :param xk: state vector mean :math:`\\hat x_k`.
        :return: Jacobian of the observation function :meth:`hf` with respect ro the robot pose :math:`J_{hfx}=\\frac{\\partial h_f(\\bar{x}_k,v_{f_k})}{\\bar{x}_k}`
        """
        NxB = self.GetRobotPose(xk)
        _hf = self.hf(NxB, Pk_bar)
        J = []
        for i in range(len(_hf)):
            J_i = self.Jhfjx(xk,self.Fj[i])
            J.append(J_i)

        # TODO: To be implemented by the student

        return np.array(J)

    def Jhfv(self, xk):  # Jacobian wrt v of the observation function for a feature
        """
        Computes the Jacobian of the observation function :meth:`hf` (eq. :eq:`eq-hf`) with respect to the observation noise :math:`v_k`.
        Normally, the observation noise in the observation B-Frame is linear (see eq. :eq:`eq-hf-element-wise`) so the Jacobian is the identity matrix.

        .. math::
            J_{hfv}&=\\frac{\\partial h_f(x_k,v_k)}{\\partial v_k}\\\\
            &=\\begin{bmatrix} \\frac{\\partial h_{F_a}(x_k,v_k)}{\\partial v_k} \\\\ \\vdots \\\\ \\frac{\\partial h_{F_b}(x_k,v_k)}{\\partial v_k} \\\\ \\vdots \\\\ \\frac{\\partial h_{F_c}(x_k,v_k)}{\\partial v_k} \\end{bmatrix}
            =\\begin{bmatrix}
                \\frac{\\partial h_{F_a}(x_k,v_k)}{\\partial v_{f1_k}} &  \\cdots & 0 & 0 & 0  & \\cdots & 0 \\\\
                \\vdots & \\ddots & \\vdots & \\vdots & \\vdots & \\ddots & \\vdots \\\\
                0 & \\cdots &  0 & \\frac{\\partial h_{F_b}(x_k,v_k)}{\\partial v_{fi_k}} &  0 & \\cdots & 0 \\\\
                \\vdots & \\ddots & \\vdots & \\vdots & \\vdots & \\ddots & \\vdots \\\\
                0 & \\cdots & 0 & 0 & 0 & \\frac{\\partial h_{F_c}(x_k,v_k)}{\\partial v_{fn_{zf_k}}}  \\\\
            \\end{bmatrix}= I_{n_{zf}\\times n_{zf}}
            :label: eq-Jhfv

        If it is not the case, this method must be overriden.

        :param xk: state vector mean :math:`\\hat x_k`.
        :return: Jacobian of the observation function :meth:`hf` with respect ro the observation noise :math:`v_k` :math:`J_{hfv}=I_{n_{zf}\\times n_{zf}}`
        """
        # J = np.zeros(self.Fj)
        # for i in range(len(self.Fj)):
        #     J[i] = [[1, 0],
        #             [0, 1]]
        J = [[1, 0],
             [0, 1]]

        return J        # TODO: To be implemented by the student


    def hfj(self, xk, Fj):  # Observation function for zf_i and x_Fj
        """
        This is the direct observation model for a single feature observation  :math:`z_{f_i}` , so it implements its related
        observation function (see eq. :eq:`eq-hfj`). For a single feature observation :math:`z_{f_i}` of the feature :math:`^Nx_{F_{H_i}}` the method computes its
        expected observation from the current robot pose :math:`^Nx_B`.
        This function uses a generic implementation through the following equation:

        .. math::
            z_{f_i}=h_{F_j}(x_k,v_k)=s2o(\\ominus ^Nx_B \\boxplus ^Nx_{F_{j}}) + v_{fi_k}
            :label: eq-hfj

        Where :math:`^Nx_B` is the robot pose included within the state vector (:math:`x_k=[^Nx_B^T~x_{rest}^T]^T`)  and :meth:`s2o` is a conversion
        function from the store representation to the observation representation.

        The method is called by :meth:`hf` to compute the expected observation for each feature
        observation contained in the observation vector :math:`z_f=[z_{f_1}^T~\\cdots~z_{f_i}^T~\\cdots~z_{f_{n_zf}}^T]^T`.

        :param xk_bar: mean of the predicted state vector
        :param Fj: map index of the observed feature: :math:`^Nx_{F_j}=self.M[Fj]`
        :return: expected observation of the feature :math:`^Nx_{F_j}`
        """

        # h(xk_bar,vk)=(-) xk_bar) [+] x_Fj + vk
        NxB = Pose3D(self.GetRobotPose(xk))        
        f2r = NxB.ominus()
        f2r = Pose3D(f2r)
        _hfj = self.s2o(f2r.boxplus(self.M[Fj])) #no noise when applied on the mean

        # TODO: To be implemented by the student
        return np.array(_hfj)

    def Jhfjx(self, xk, F_index):  # Jacobian wrt x of the observation function for feature observation i
        """
        Jacobian of the single feature direct observation model.

        Parameters:
            xk: (3,1) state vector mean
            Fj: (int) map index of the observed feature
        Returns:
            J: (2.3) Jacobian of the single feature direct observation model.
        """

        # Receive robot pose
        NxB = self.GetRobotPose(xk)
       
        # Compute Jacobian of the observation function
        BxN = NxB.ominus() 
        J_o2s = self.J_o2s(Pose3D(BxN).boxplus(self.M[F_index]))

        # Compute Jacobian of the inverse observation model
        J_ominus = NxB.J_ominus()

        # NOTE: need to change the xk into Pose 3D
        xk = Pose3D(xk)

        # Compute Jacobian of the boxplus
        J_1boxplus = xk.J_1boxplus(self.M[F_index])

        # Jacobian of the single feature direct observation model
        J = J_o2s @ J_1boxplus @ J_ominus
        return J

    def g(self, xk, BxFj):  # xBp [+] (BxFj + vk)
        """
        This method provides a generic implementation of the inverse observation model. It computes the feature pose in the N-Frame :math:`^Nx_{F_j}` by compounding the robot pose :math:`^Nx_B`, from where the observation was taken, with the  B-Frame referenced feature
        observation :math:`^Bx_{F_j}`:

        .. math::
            ^Nx_{F_j} = ^Nx_B \\boxplus o2s(^Bx_{F_j} +v_k)
            :label: eq-g

        In this case, :meth:`o2s` is the conversion function converting from the observation space to the representation one.
        It is worth noting that the robot pose :math:`^Nx_B` is included within the state vector :math:`x_k` but might not be the whole state vector.
        For instance, in some cases the state vector may include as well the robot velocity :math:`x_k=[^Nx_B^T~^B\\nu_k^T]^T`.
        Note that the :meth:`g` works with a single feature observation, instead than with a vector of feature observations.

        :param xk: mean state vector containing the robot pose :math:`^Nx_B` from where the observation was taken
        :param BxFj: feature observation in the B-Frame :math:`^Bx_{F_j}`
        :return: mean feature pose in the N-Frame :math:`^Nx_{F_j}`
        """

        NxB = self.GetRobotPose(xk)
        NxFj = Pose3D(NxB).boxplus(self.o2s(BxFj))

        # TODO: To be implemented by the student
        return NxFj

    def Jgx(self, xk, BxFj):  # Jacobian wrt xk of the inverse sensor model for a single feature observation
        """
        Jacobian of the inverse observation model :meth:`g`, with respect to the state vector :math:`x_k`.
        According to the generic implementation of the inverse observation model :meth:`g` eq. :eq:`eq-g`, the Jacobian is computed as follows:

        .. math::
            J_{gx}=\\frac{\\partial g(^Nx_B,^Bx_{F_j},v_k)}{\\partial x_k}=\\begin{bmatrix} J_{1\\boxplus}(^Nx_B,o2s(^Bx_{F_j})) & 0  \\end{bmatrix}
            :label: eq-Jgx

        The zero submatrix, if present, corresponds to the derivate with respect to the non-positional elements of the
        state vector, for instance the robot velocity :math:`^B\\nu_k`, in case this was included within the state vector.
        If the state vector only containes the pose, then the 0 submatix vanishes.

        :param xk_bar: predicted state vector
        :return: Jacobian of the inverse observation model :meth:`g` with respect to the state vector (eq. :eq:`eq-Jgx`)
        """

        # TODO: To be implemented by the student
        NxB = self.GetRobotPose(xk)
        J = [0, 0]
        J[0] = Pose3D(NxB).J_1boxplus(self.o2s(BxFj))
        
        return J

    def Jgv(self, xk, BxFj):
        """
        Jacobian of the inverse observation model :meth:`g`, with respect to the observation noise :math:`v_k`.
        According to the generic implementation of the inverse observation model :meth:`g` eq. :eq:`eq-g`, the Jacobian is computed as follows:

        .. math::
            J_{gv}=\\frac{\\partial g(^Nx_k,^Bx_{F_j},v_k)}{\\partial v_k}=J_{2\\boxplus}(^Nx_B,o2s(^Bx_{F_j})) J_{o2s}(^Bx_{F_j})
            :label: eq-Jgv

        :param xk: state vector containing the robot pose :math:`^Nx_B` from where the observation was taken
        :param BxFj: feature observation in the B-Frame :math:`^Bx_{F_j}`
        :return: Jacobian of the inverse observation model :meth:`g` with respect to the observation noise :math:`J_{gv}` (see eq. :eq:`eq-Jgv`).
        """
        # TODO: To be implemented by the student
        NxB = self.GetRobotPose(xk)
        J = Pose3D(NxB).J_2boxplus(Pose3D(BxFj)) @ self.J_o2s(BxF)
        return J


class Cartesian2DMapFeature(MapFeature):
    """
    This class inherits from the :class:`MapFeature` and implements a 2D Cartesian feature model for the MBL problem. The Cartesian coordinates are used for both,
    observing the feature and for its storage within the map. This class overrides the :meth:`GetFeatures` method to read
    the 2D Cartesian Features from the robot.
    """

    def GetFeatures(self):
        """
        Reads the Features observations from the sensors. For all features within the field of view of the sensor, the
        method returns the list of robot-related poses and the covariance of their corresponding observation noise in **2D Cartesian coordinates**.

        :return zk, Rk: list of Cartesian features observations in the B-Frame and the covariance of their corresponding observation noise:
            * :math:`z_k=[^Bx_{F_i}^T \\cdots ^Bx_{F_j}^T \\cdots ^Bx_{F_k}^T]^T`
            * :math:`R_k=block\\_diag([R_{F_i} \\cdots R_{F_j} \\cdots R_{F_k}])`

        """
        ranges, rangesCov = self.robot.ReadRanges()

        # NOTE: rejection of reading out of the range
        ranges = [r for r in ranges if r > 0] # remove invalid readings


        # NOTE: transform the ranges to cartesian
        # zk list of euclidean distances form the robot
        # Need to convert them into xy coordinates
        theta = self.robot.xsk[2]
        zk = np.zeros((2 * len(ranges), 1))
        for i, r in enumerate(ranges):
            zk[2*i, 0] = r * cos(theta)
            zk[2*i+1, 0] = r * sin(theta)

        # Creating covariance of the features coordinatates 
        listRk = []
        for i in range(len(ranges)):
            listRk.append(rangesCov[0,0])
            listRk.append(rangesCov[1,1])

        Rk = np.diag((listRk))

        return zk, Rk


