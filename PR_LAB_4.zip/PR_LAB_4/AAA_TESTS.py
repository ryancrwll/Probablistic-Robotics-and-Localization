from Feature import * 
from Pose import *
import numpy as np


FeatureReading = CartesianFeature(np.arange((3)).reshape(3,1))
RobotPosition = Pose3D(np.arange((3)).reshape(3,1))

FeaturePosition = CartesianFeature.boxplus(BxF=FeatureReading, NxB=RobotPosition)

