from scipy.stats import chi2
from GFLocalization import *
from MapFeature import *
from EKF import *
import math

class FEKFMBL(GFLocalization, MapFeature):
    """
    Feature Extended Kalman Filter Map based Localization class. Inherits from :class:`GFLocalization.GFLocalization` and :class:`MapFeature.MapFeature`.
    The first one provides the basic functionality of a localization algorithm, while the second one provides the basic functionality required to use features.
    :class:`FEKFMBL.FEKFMBL` extends those classes by adding functionality to use a map based on features.
    """
    xB = -2  # constant used to index the state vector and the covariance matrix, to select the robot state
    x_eta = -1  # constant used to index the state vector and the covariance matrix, to select the robot pose
    def __init__(self, M, alpha,  *args):
        """
        Constructor of the FEKFMBL class.

        :param xBpose_dim: dimensionality of the robot pose within the state vector
        :param xB_dim: dimensionality of the state vector
        :param xF_dim: dimentsionality of a feature
        :param zfi_dim: dimensionality of a single feature observation
        :param M: Feature Based Map :math:`M =[^Nx_{F_1}^T~...~^Nx_{F_{n_f}}^T]^T`
        :param alpha: Chi2 tail probability. Confidence interaval of the individual compatibility test
        :param args: arguments to be passed to the EKFLocalization constructor
        """

        super().__init__(*args)  # initialize EKFLocalization
        self.xBpose_dim = self.Pose().shape[0] # Robot Pose dimensionality
        self.xB_dim = self.xk_1.shape[0]  # Robot State dimensionality (might include the velocity or other terms)
        self.xF_dim = self.Feature.feature.shape[0]  # Feature dimensionality
        self.zfi_dim = self.s2o(self.Feature.feature).shape[0]  # dimensionality of a single feature observation

        self.M = M  # Feature Based Map
        self.nf = len(M)  # number of features
        self.alpha = alpha  # Chi2 tail probability - Confidence interval 95%
        self.plt_zf_ellipse = []  # used for plotting the robot ellipse
        self.plt_zf_line = []  # used for plotting the line towards the robot ellipse

        self.plt_robotEllipse, = plt.plot([], [], 'b')
        self.plt_hf_ellipse = []
        self.plt_zf_ellipse = []
        self.plt_zf_line = []
        self.plt_samples = []

    def h(self, xk, Pk_bar):  # overloaded to stack measurements and feature observations
        """
        We do differenciate two types of observations:

        Measurements: zm correspond to observations of the state variable (position, velocity, etc...)
        Feature Observations: zf` correspond to observations of the features (CartesianFeature, PolarFeature, EsphericalFeature, etc...).

        This method implements the full observation model including the measurements and feature observations:

            zk = h(xk,vk) -> [zm, zf]^T = [hm(xk,vm), hf(xk,vf)] ~;~ v_k=[v_m^T ~v_f^T]^T

        This method calls hm to compute the expected measurements and  the MapFeature.MapFeature.hf method to compute the expected feature observations.
        The method returns an stacked vector of expected measurements and feature observations.

        Parameters:
            xk: mean state vector used as linearization point
            Pk: covariance state vector.
        Returns:
            h_mf: Joint stacked vector of the expected mesurement and feature observations
        """
        ## Get Measurement
        #h_mf = [[self.hf(xk, Pk_bar)],
        #        [self.hm(xk)]]

        hf = self.hf(xk, Pk_bar) 
        hf = hf.flatten().T # 6,
        hf = hf.reshape(len(hf),1)
       
        hm = self.hm(xk)  #1,
        # Get Measurement
        h_mf = np.block([[hm], #theta. 1x1
                        [hf]]) # f5 f2. 4x1

        return h_mf

    def hm(self,xk):
        """
        Measurement observation model. 
        This method computes the expected measurements hm(xk,vm) given the mean state vector xk and the measurement noise vm. 
        It is implemented by calling to the ancestor class EKF.EKF.h method.

        Parameters:
            xk: mean state vector.
        Return:
            _hm: expected measruments.
        """
        _hm = xk[2]
        # TODO: To be completed by the student

        return _hm

    def SquaredMahalanobisDistance(self, hfj, Pfj, zfi, Rfi):
        """
        Computes the squared Mahalanobis distance between the expected feature observation Fj and the feature observation z(Fj)

        :param hfj: expected feature observation
        :param Pfj: expected feature observation covariance
        :param zfi: feature observation
        :param Rfi: feature observation covariance
        :return: Squared Mahalanobis distance between the expected feature observation :math:`hf_j` and the feature observation :math:`z_{f_i}`
        """

        #xy_err = np.array([(hfj[0]-zfi[0]), (hfj[1]-zfi[1])])
        # Because zfi receive a range, need to convert it in a cartesian

        delta_x = hfj[0][0]- zfi[0][0] * cos(self.xk_bar[2]) #BUG zfi had weird shape
        delta_y = hfj[1][0]- zfi[1][0] * sin(self.xk_bar[2])
        #xy_err = np.array([(hfj[0]-zfi[0]), (hfj[1]-zfi[1])])
        xy_err = np.array([delta_x, delta_y])
        # NOTE: check how should it be the dimension of hfk and zfi
        covar = np.array(Pfj + Rfi)

        # NOTE: check how should it be the dimension of hfk and zfi
        #D2_ij = xy_err @ np.linalg.inv(covar) @ xy_err.T
        D2_ij = xy_err.T @ np.linalg.inv(covar) @ xy_err

        return D2_ij
                                                          #2D features
    def IndividualCompatibility(self, D2_ij, alpha, dof):
        """
        Computes the individual compatibility test for the squared Mahalanobis distance :math:`D^2_{ij}`. The test is performed using the Chi-Square distribution with :math:`dof` degrees of freedom and a significance level :math:`\\alpha`.

        :param D2_ij: squared Mahalanobis distance
        :param dof: number of degrees of freedom
        :param alpha: confidence level
        :return: bolean value indicating if the Mahalanobis distance is smaller than the threshold defined by the confidence level
        """
        # TODO: To be completed by the student
        threshold = chi2.pdf(alpha, dof)
        isCompatible = False
        if D2_ij > threshold:
            isCompatible = True

        return isCompatible

    def ICNN(self, hf, Phf, zf, Rf, dim):
        """
        Individual Compatibility Nearest Neighbor (ICNN) data association algorithm. 
        Given a set of expected feature observations hf and a set of feature observations zf, the algorithm returns a pairing hypothesis
        H that associates each feature observation zf with the expected feature observation h(fj) that minimizes the Mahalanobis distance D^2_{ij}.

        Parameters:
            hf: vector of expected feature observations
            Phf: Covariance matrix of the expected feature observations
            zf: vector of feature observations
            Rf: Covariance matrix of the feature observations
            dim: feature dimensionality
        Returns:
            H: The vector of asociation hypothesis H
        """

        # # TODO: To be completed by the student
        # H = []
        # dof = dim
        # #for j in range(len(self.M)): # NOTE: from the slide is number of readings
        # for j in range(len(zf)):
        #     nearest = -1
        #     D2_min = np.inf
        #     for i in range(len(zf)):
        #         # D2_ij = self.SquaredMahalanobisDistance(hf[j], Phf[j], zf[i], Rf[i])
        #         # NOTE: Rf is always the same in this case, because is Rk from the readranges
        #         Rfi = Rf[2*i:2*i+2,2*i:2*i+2]
        #         D2_ij = self.SquaredMahalanobisDistance(hf[j], Phf[j], zf[i], Rfi)
        #         if self.IndividualCompatibility(D2_ij, self.alpha, dof) and D2_ij<D2_min:
        #             nearest = i
        #             D2_min = D2_ij
        #     H.append(nearest)
        
        H = []
        dof = dim
        for read_index in range(len(zf) // 2): # for each feature read
            nearest = -1
            D2_min = np.inf # set min distance to infinite to find the closest one

            # NOTE: for each readed feature, so for each zf, we compare to all F in M, and fnd the closest one
            # Save components and covariance for eache readed feature
            zf_i = zf[2*read_index : 2*read_index+2]  # 2 by 2 -> zf = [Fx, Fy]^T
            Rf_i = Rf[2*read_index : 2*read_index+2, 2*read_index : 2*read_index+2] # Rf = diag(sigma Fx, sigmaFy)

            for F_index in range(self.nf): # For each feature in the map

                D2_ij = self.SquaredMahalanobisDistance(hf[ 2*F_index :  2*F_index + 2], 
                                                        Phf[2*F_index :  2*F_index + 2, :], #2nx2
                                                        zf_i, 
                                                        Rf_i)

                if self.IndividualCompatibility(D2_ij, self.alpha, dof) and D2_ij<D2_min:
                    nearest = F_index
                    D2_min = D2_ij

            H.append(nearest)

        H = np.array(H).reshape(len(H), 1)
        
        return H

    def DataAssociation(self, xk, Pk, zf, Rf):
        """
        Data association algorithm. 
        Given state vector (xk, Pk) and a set of feature observations zf and its covariance matrices Rf, 
        the algorithm computes the expected feature observations hf and its covariance matrices Pf. 
        Then it calls an association algorithms like ICNN (JCBB, etc.) to build a pairing hypothesis associating the observed features zf
        with the expected features observations hf.

        The vector of association hypothesis H is stored in the H attribute and its dimension is the
        number of observed features within :math:`z_f`. Given the j(th) feature observation zfj, self.H[j]=i
        means that zfj has been associated with the :math:`i^{th}` feature . If *self.H[j]=None* means that zfj
        has not been associated either because it is a new observed feature or because it is an outlier.

        :param xk: mean state vector including the robot pose
        :param Pk: covariance matrix of the state vector
        :param zf: vector of feature observations
        :param Rf: Covariance matrix of the feature observations
        :return: The vector of asociation hypothesis H
        """
        hf = np.array(self.hfj(xk, 0)).reshape(2,1) #BUG reshape after computing jacobians
        Pf = np.array(self.Jhfjx(xk, 0) @ Pk @ self.Jhfjx(xk, 0).T).reshape(2,2) #BUG initialized arrrays with first value so i can use vstack
        for i in range(self.nf):
            if i != 0:
                hf = np.vstack((hf,(self.hfj(xk, i))))
                Pf = np.vstack((Pf, (self.Jhfjx(xk, i) @ Pk @ self.Jhfjx(xk, i).T)))
        
        size = len(Pf)
        hf.reshape(size, 1) #BUG reshaping again
        Pf.reshape(size, 2)
        H = self.ICNN(np.array(hf), np.array(Pf), zf, Rf, self.xF_dim)

        # TODO: To be completed by the student

        return H

    def Localize(self, xk_1, Pk_1):
        """
        Localization iteration. Reads the input of the motion model, performs the prediction step (:meth:`EKF.EKF.Prediction`), reads the measurements
        and the features, solves the data association calling :meth:`DataAssociation` and the performs the update step (:meth:`EKF.EKF.Update`) and logs the results.
        The method also plots the uncertainty ellipse (:meth:`PlotUncertainty`) of the robot pose, the feature observations and the expected feature observations.

        :param xk_1: previous state vector
        :param Pk_1: previous covariance matrix
        :return xk, Pk: updated state vector and covariance matrix
        """

        # TODO: To be completed by the student
        # Get input from simulated robot
        uk, Qk = self.GetInput()

        # Make prediction
        xk_bar, self.Pk_bar = self.Prediction(uk, Qk, xk_1, Pk_1)

        # Get measurements from simulated robot
        zm, Rm, Hm, Vm = self.GetMeasurements()

        # Get readed features from simulated robot
        zf, Rf = self.GetFeatures()

        # Data association
        H = self.DataAssociation(xk_bar, self.Pk_bar, zf, Rf)

        # Stack measurements
        zk, Rk, Hk, Vk, znp, Rnp = self.StackMeasurementsAndFeatures(zm, Rm, Hm, Vm, zf, Rf, H)
        print(self.xk_bar)

        # Update
        xk, Pk = self.Update(zk, Rk, self.xk_bar, self.Pk_bar, Hk, Vk) 

        return xk, Pk

    def StackMeasurementsAndFeatures(self, zm, Rm, Hm, Vm, zf, Rf, H):
        """
        Given the vector of  measurements observations zm together with their covariance matrix Rm,
        the vector of feature observations zf together with their covariance matrix Rf, The measurement observation matrix Hm, the
        measurement observation noise matrix Vm and the vector of feature associations H, this method
        returns the joint observation vector xk, its related covariance matrix Rk, the stacked
        Observation matrix Hk, the stacked noise observation matrix Vk, the vector of non-paired features znp and its noise covariance matrix Rnp.
        It is assumed that the measurements and the features observations are independent, therefore the covariance matrix
        of the joint observation vector is a block diagonal matrix.

        PARAMETERS:
            zm: measurement observations vector
            Rm: covariance matrix of the measurement observations
            Hm: measurement observation matrix
            Vm: measurement observation noise matrix
            zf: feature observations vector
            Rf: covariance matrix of the feature observations
            H: features associations vector
        Rreturns:
            zk: vector of joint measurement and feature observations.
            Rk: covariance matrix of the joint measurement`
        """

        zp, Rp, Hp, Vp, znp, Rnp = self.SplitFeatures(zf, Rf, H)

        # NOTE: meaning?
        if zm is None:
            zk, Rk, Hk, Vk = zp, Rp, Hp, Vp
        elif zp is None:
            zk, Rk, Hk, Vk = zm, Rm, Hm, Vm
        else:
            zk = np.block([[zm],
                           [zp]])

            Rk = np.block([[Rm, np.zeros((Rm.shape[0], Rp.shape[0]))], 
                          [np.zeros((Rp.shape[0], Rm.shape[0])), Rp]])
            
            Hk = np.block([[Hm],
                          [Hp]])
            
            Vk = np.block([[Vm, np.zeros((Vm.shape[0], Vp.shape[0]))], 
                          [np.zeros((Vp.shape[0], Vm.shape[0])), Vp]])


        return zk, Rk, Hk, Vk, znp, Rnp

    def SplitFeatures(self, zf, Rf, H):
        """
        Given the vector of feature observations zf and their covariance matrix Rf, and the vector of
        feature associations H, this function returns the vector of paired feature observations zp together with
        its covariance matrix Rp, and the vector of non-paired feature observations znp together with its covariance matrixRnp`.
        The paired observations will be used to update the filter, while the non-paired ones will be considered as outliers.
        In the case of SLAM, they become new feature candidates.

        Parameters:
            zf: vector of feature observations
            Rf: covariance matrix of feature observations
            H:  hypothesis of feature associations
        Returns:
            zp: vector of paired feature observations
            Rp: covariance matrix of paired feature observations
            znp: vector of non-paired feature observations
            Hp: 
            Vp: 
            Rnp: covariance matrix of non-paired feature observations
        """

        # Initialize empty lists
        # NOTE: yet idk how to use these 
        zp = []
        znp = Rnp = []

        for i in range(len(H)):
            Fj = H[i].item() # Feature association #BUG Fixed H had weird shape after numpy conversion
            # NOTE: should't it be Fj != None, because th i will always be diffeent from none
            if Fj is not None: # If paired
                if zp == []:
                    zp = zf[i]
                    # NOTE: in this case the cov will be x,y of the readings 2x2, but it migh be that we'll need to implement the reading compass 1x1, so Rf has to be a list of arrays
                    Rp = Rf
                    Hp = self.Jhfjx(self.xk_bar, Fj) 
                    Vp = np.eye(zf[i].shape[0])
                else:
                    zp = np.block([[zp], [zf[i]]])

                    # NOTE: we need to be sure that Rf is an array and is a square array nxn, but for now we give only one tyoe of covariance
                    # if Rf[i] != np.ndarray:
                    #     Rf[i] = np.array([Rf[i]])
                    Rp = np.block([ [Rp, np.zeros((Rp.shape[0], Rf.shape[0]))],
                                    [np.zeros((Rf.shape[0], Rp.shape[1])), Rf]])
                    
                    # NOTE: !!!! this should be xk non xk_1!!!
                    # BUG: idk how to clal xk from here
                    Hp = np.block([[Hp], [self.Jhfjx(self.xk_1, Fj)]])

                    Vp = np.block([ [Vp, np.zeros((Vp.shape[0], zf[i].shape[0])),],
                                    [np.zeros((zf[i].shape[0], Vp.shape[1])), np.eye(zf[i].shape[0])]])

        return zp, Rp, Hp, Vp, znp, Rnp

    def PlotFeatureObservationUncertainty(self, zf, Rf, color):  # plots the feature observation uncertainty ellipse
        """
        Plots the uncertainty ellipse of the feature observations. This method is called by :meth:`FEKFMBL.PlotUncertainty`.

        :param zf: vector of feature observations
        :param Rf: covariance matrix of the feature observations
        """

        zf=BlockArray(zf,self.zfi_dim)
        Rf=BlockArray(Rf,self.zfi_dim)

        if zf is not None:
            # Remove previous feature observation ellipses
            for i in range(len(self.plt_zf_ellipse)):
                self.plt_zf_ellipse[i].remove()
                self.plt_zf_line[i].remove()
            self.plt_zf_ellipse = []
            self.plt_zf_line = []

        NxB = self.GetRobotPose(self.robot.xsk)

        # For all feature observations
        nzf = 0 if zf is None else zf.size // self.zfi_dim
        for i in range(0, nzf):
            BxF = self.Feature(zf[[i]])  # feature observation in the B-Frame
            BRF = Rf[[i,i]]  # feature observation covariance in the B-Frame
            NxF = self.g(NxB, BxF)
            J = self.Jgv(NxB, BxF)
            NRf = J @ BRF @ J.T
            NxF_Plot = NxF.ToCartesian()
            NRF_Plot = NxF.J_2c() @ NRf @ NxF.J_2c().T
            feature_ellipse = GetEllipse(NxF_Plot, NRF_Plot)
            plt_ellipse, = plt.plot(feature_ellipse[0], feature_ellipse[1], color)
            plt_line, = plt.plot([self.robot.xsk[0], NxF_Plot[0]],
                                 [self.robot.xsk[1], NxF_Plot[1]], color+'-.')
            self.plt_zf_ellipse.append(plt_ellipse)
            self.plt_zf_line.append(plt_line)
            #for j in range(len(self.M)): print("M[",j,"]=", self.M[j].ToCartesian().T)

    def PlotExpectedFeaturesObservationsUncertainty(self):
        """
        For all features in the map, this method plots the uncertainty ellipse of the expected feature observations. This method is called by :meth:`FEKFMBL.PlotUncertainty`.
        """
        for i in range(len(self.plt_hf_ellipse)):
            self.plt_hf_ellipse[i].remove()
        self.plt_hf_ellipse = []

        # Plot Expected Feature Observation Ellipses
        for Fj in range(self.nf):   # for all map features
            h_Fj = self.Feature(self.hfj(self.xk, Fj)) # expected feature observation in the B-Frame in the observation space
            J = self.Jhfjx(self.xk, Fj)
            P_h_Fj = J @ self.Pk @ J.T # expected feature observation covariance in the B-Frame in the observation space

            Nhx_Fj = self.g(self.xk, h_Fj) # expected feature observation in the N-Frame in storage space
            #Jx = self.Jgx(self.xk, h_Fj)
            Jv = self.Jgv(self.xk, h_Fj)

            #NP_Fj = Jx @ self.Pk @ Jx.T + Jv @ P_h_Fj @ Jv.T # expected feature observation covariance in the N-Frame in storage representation
            NP_Fj = Jv @ P_h_Fj @ Jv.T  # expected feature observation covariance in the N-Frame in storage representation

            ellipse = GetEllipse(Nhx_Fj.ToCartesian(), Nhx_Fj.J_2c() @ NP_Fj @ Nhx_Fj.J_2c().T)
            plt_ellipse, = plt.plot(ellipse[0], ellipse[1], 'black')  # plot it
            self.plt_hf_ellipse.append(plt_ellipse)  # and add it to the list

            #self.PlotSampleObservationSpace(self.xk, h_Fj, P_h_Fj, 100)

    def PlotRobotUncertainty(self):  # plots the robot trajectory and its uncertainty ellipse
        """
        Plots the robot trajectory and its uncertainty ellipse. This method is called by :meth:`FEKFMBL.PlotUncertainty`.

        """
        # Plot Robot Ellipse
        robot_ellipse = GetEllipse(self.robot.xsk, self._GetRobotPoseCovariance(self.Pk))
        self.plt_robotEllipse.set_data(robot_ellipse[0], robot_ellipse[1])  # update it

        # Plot Robot Trajectory
        self.xTraj.append(self.xk[0, 0])
        self.yTraj.append(self.xk[1, 0])
        self.trajectory.pop(0).remove()
        self.trajectory = plt.plot(self.xTraj, self.yTraj, marker='.', color='blue', markersize=1)

    def PlotUncertainty(self,zf,Rf):
        """
        Plots the uncertainty ellipses of the robot pose (:meth:`PlotRobotUncertainty`), the feature observations
        (:meth:`PlotFeatureObservationUncertainty`) and the expected feature observations (:meth:`PlotExpectedFeaturesObservationsUncertainty`).
        This method is called by :meth:`FEKFMBL.Localize` at the end of a localization iteration in order to update
        the online  visualization.

        :param zf: vector of feature observations
        :param Rf: covariance matrix of the feature observations
        """
        if self.k % self.robot.visualizationInterval == 0:
            self.PlotRobotUncertainty()
            self.PlotFeatureObservationUncertainty(zf, Rf,'b')
            self.PlotExpectedFeaturesObservationsUncertainty()

    def GetRobotPose(self, xk):
        """
        Gets the robot pose from the state vector.

        :param xk: mean of the state vector:math:`x_k`
        :return: The robot pose :math:`x_{B_k}`
        """
        return self.Pose(xk[0:self.xBpose_dim])

    def GetRobotPoseCovariance(self, Pk):
        """
        Returns the robot pose covariance from the state covariance matrix.

        :param Pk: state vector covariance matrix :math:`P_k`
        :return: robot pose covariance :math:`P_{B_k}`
        """
        return Pk[0:self.xBpose_dim, 0:self.xBpose_dim]

