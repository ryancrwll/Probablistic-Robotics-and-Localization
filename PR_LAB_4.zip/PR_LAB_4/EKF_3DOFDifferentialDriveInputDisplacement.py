from GFLocalization import *
from EKF import *
from DR_3DOFDifferentialDrive import *
from DifferentialDriveSimulatedRobot import *

class EKF_3DOFDifferentialDriveInputDisplacement(GFLocalization, DR_3DOFDifferentialDrive, EKF):
    """
    This class implements an EKF localization filter for a 3 DOF Diffenteial Drive using an input displacement motion model incorporating
    yaw measurements from the compass sensor.
    It inherits from :class:`GFLocalization.GFLocalization` to implement a localization filter, from the :class:`DR_3DOFDifferentialDrive.DR_3DOFDifferentialDrive` class and, finally, it inherits from
    :class:`EKF.EKF` to use the EKF Gaussian filter implementation for the localization.
    """
    def __init__(self, kSteps, robot, *args):
        """
        Constructor. Creates the list of  :class:`IndexStruct.IndexStruct` instances which is required for the automated plotting of the results.
        Then it defines the inital stawe vecto mean and covariance matrix and initializes the ancestor classes.

        :param kSteps: number of iterations of the localization loop
        :param robot: simulated robot object
        :param args: arguments to be passed to the base class constructor
        """

        self.dt = 0.1  # dt is the sampling time at which we iterate the KF
        x0 = np.zeros((3, 1))  # initial state x0=[x y z psi u v w r]^T\\
        P0 = np.zeros(shape=(3, 3)) # initial covariance

        # this is required for plotting
        index = [IndexStruct("x", 0, None), IndexStruct("y", 1, None), IndexStruct("z", 2, 0), IndexStruct("yaw", 3, 1)]

        self.t_1 = 0
        self.t = 0
        self.Dt = self.t - self.t_1

        super().__init__(index, kSteps, robot, x0, P0, filter, *args)

    def f(self, xk_1, uk):
        """
        Motion model of the EKF.

        :param xk_1: previous mean state vector
        :param uk: input vector
        :return xk_bar, Pk_bar: predicted mean state vector and its covariance matrix
        """
        # TODO: To be completed by the studentù
        xk_bar = Pose3D(xk_1).oplus(uk)        
        return xk_bar

    def Jfx(self, xk_1):
        """
        Jacobian of the motion model with respect to the state vector.

        :param xk_1: Linearization point. By default the linearization point is the previous state vector taken from a class attribute.
        :return: Jacobian matrix
        """
        # TODO: To be completed by the student

        J = Pose3D(xk_1).J_1oplus(self.uk)
        return J

    def Jfw(self, xk_1):
        """
        Jacobian of the motion model with respect to the noise vector.

        :param xk_1: Linearization point. By default the linearization point is the previous state vector taken from a class attribute.
        :return: Jacobian matrix
        """
        # TODO: To be completed by the student

        #theta = xk_1[2].item()
        #J = np.array([[-np.sin(theta),  0, 0],
        #              [ np.cos(theta),  0, 0],
        #              [             0,  0, 1]])
        J = Pose3D(xk_1).J_2oplus()
        return J

    def h(self, xk):  #:hm(self, xk):
        """
        The observation model of the EKF is given by:

        .. math::
            z_k=h(x_k,v_k)
            :label: eq-EKF-observation-model

        This method computes the mean of this direct observation model. Therefore it does not depend on v_k since it is
        a zero mean Gaussian noise.

        :param xk: mean of the predicted state vector. By default it is taken from the class attribute.
        :return: expected observation vector
        """
        # TODO: To be completed by the student
        h = xk[2] 

        return h  # return the expected observations

    def GetInput(self):
        """
        Method that receives the input from the robot and convert it into input model of the localizer.
        Outputs :\n
        uk: 2x1 np.array [d, dTheta] displacement of the robot and displacement of the angle\n
        Qk: 2x2 np diagonal matrix, covariance of the input \n
        """
        # receive input from simulated robot
        # encoder Input = [n pulses left, n pulses right], covariance = diagonal[ sigma_l^2, sigma_r^2]
        encIn, encCov = self.robot.ReadEncoders() # reurtn impulses for each wheel and covariance of input

        # converting encoders read into a displacement
        r = self.wheelRadius
        L = self.wheelBase
        pulse_round = (self.robot.pulse_x_wheelTurns) # pulses wheel evolution

        # wheels angular velocities
        omega_l = (encIn[0] / pulse_round) * 2 * np.pi
        omega_r = (encIn[1] / pulse_round) * 2 * np.pi

        # Wheel linear displacements
        disp_l = omega_l * r
        disp_r = omega_r * r
    
        # Compute robot displacement and angular displacement
        d = (disp_l + disp_r) / 2  # Linear displacement in the robot's frame
        dTheta = (r / L) * (omega_r - omega_l)  # Angular displacement (yaw change)

        # Convert to scalars if needed
        d = d.item()
        dTheta = dTheta.item()

        # Construct input vector
        uk = np.array([d, 0, dTheta]).reshape(3, 1)

        # TODO: ##############################################
        # Use the process noise
        # Jacobian of the motion model with respect of the input ???
        A = np.array([[       np.pi*r/pulse_round,       np.pi*r/pulse_round],
             [                         0,                         0],
             [-2*np.pi*r/(pulse_round*L), 2*np.pi*r/(pulse_round*L)]])
        Qk = A @ encCov @ A.T

        
        return uk, Qk

    def GetMeasurements(self):  # override the observation model
        """
        The measurement in this robot is made by distance sensor.

        **Outputs** :\n
        **zk**: compass reading\n
        **Rk**: 2x2 np diagonal matrix, covariance of the readings \n
        **Hk**: 3x3 np matrix, Jacobian of the state measurement wtr measurement
        **Vk**: 3x3 np matrix, Jacobian of the state measurement wtr noise 
        """

        # zk = theta  Rk = sigma_theta^2
        zk, Rk = self.robot.ReadCompass()

        Hk = np.array([0, 0, 1]).reshape(1,3)

        # Jacobian of the measurement wrt Rk
        Vk = np.identity(1)

        return zk, Rk, Hk, Vk


if __name__ == '__main__':

    M =   [(np.array([[-40, 5]]).T),
           (np.array([[-5, 40]]).T),
           (np.array([[-5, 25]]).T),
           (np.array([[-3, 50]]).T),
           (np.array([[-20, 3]]).T),
           (np.array([[40,-40]]).T)]  # feature map. Position of 2 point features in the world frame.

    xs0 = np.zeros((6,1))  # initial simulated robot pose x_sk = [x y theta u v r].T
    usk = np.array([[0.5, 0.03]]).T # input model simulated robot
    robot = DifferentialDriveSimulatedRobot(xs0, M)  # instantiate the simulated robot object

    kSteps = 5000

    index = [IndexStruct("x", 0, None), IndexStruct("y", 1, None), IndexStruct("yaw", 2, 1)]

    x0 = np.zeros((3, 1)) # initial predicted robot pose x_k = [x y theta].T
    P0 = np.zeros(shape=(3,3)) # initial covariance predicted robot


    dd_robot = EKF_3DOFDifferentialDriveInputDisplacement(kSteps,robot)  # initialize robot and KF
    dd_robot.LocalizationLoop(x0, P0, usk) # call loop
    
    
    exit(0)